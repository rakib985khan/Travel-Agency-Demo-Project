<html>
<head>
<link rel="stylesheet" href="about.css" />
</head>
<body>
<nav>
<h1> Message from CEO </h1>
</nav>
</br></br></br></br></br></br></br></br></br> </br>
</br></br></br></br></br></br></br></br></br></br></br></br></br>
<p align="justify"> I warmly welcome you all to my company, BD Travel Agency. </p>
<p align="justify">Thank you for spending your valuable time going through my website.</p>
<p align="justify">I hope that once you go throughout the entire website, you will not return empty handed. </p>
<p align="justify">In this competitive era of business, competition and trust are inversely related to each other. </p>
<p align="justify">s competition increases, trust of clients decreases as they tend to be in a dilemma about which company to trust. Therefore, Obokash.</p>
<p align="justify"> com is here to secure your trust with its top-notch service. I love travelling a lot and know the essentials of its services.</p>
<p align="justify"> I have made this company to fulfill all the essentials of travelling.</p>
 </br></br></br>
 <div>
 <p> Thank you</p>
 <p> Regards</p>
 <p> Md Rakib Khan </p>
 <p> Founder & CEO,BD Travel Agency</p>
 </div>

</body>

</html>