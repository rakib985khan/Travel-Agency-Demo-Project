<html>
<title> Contact info </title>
<head>
<link rel="stylesheet" href="contact.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.css"/>
</head>
<body>
<nav>
<div class="contact-info">
<div class="card">
<i class="card-icon far fa-envelope"></i>
<p> rakib.982khan@gmail.com </p>
</div>
<div class="card">
<i class="card-icon fas fa-phone"></i>
<p>+880177521592 </p>
</div>
<div class="card">
<i class="card-icon fas fa-map-marker-alt"></i>
<p>Shariatpur,Dhaka,Bangladesh </p>
</div>
  
</div>
</nav>
</body>
</html>