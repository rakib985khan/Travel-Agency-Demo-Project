<?php
$dbServer="localhost";

$dbUser = "root";
$dbPass="";
$db="project";
$conn = mysqli_connect($dbServer,$dbUser,$dbPass,$db);
?>