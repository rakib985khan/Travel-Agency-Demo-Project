<html>
<head>
<title>Rakib Khan</title>
</head>
<body>
<h1 align="center"> SHARIATPUR </h1> <hr/>
<img align="right"src="spur.gif">
<p align="justify"><b>Shariatpur: </b>(Bengali: শরিয়তপুর জেলা, Shariatpur Jela also Shariatpur Zila) is a district in the Dhaka Division of central Bangladesh. It is bounded by Munshiganj district on the north, Barisal district on the south, Chandpur district on the east, Madaripur district on the west. Water bodies Main rivers: Padma, Meghna, Palong (Kirtinasha) and Jayanti. Of the six upazilas of the district Bhedarganj Upazila is the largest (311.24 square kilometres (120.17 sq mi)) and Damudya Upazila is the smallest (91.76 square kilometres (35.43 sq mi)).</p>
<h3> History </h3> <hr/>
<p align="justify">Shariatpur was named after Haji Shariatullah (1781–1840), who was the founder of Faraizi Movement and an eminent Islamic reformer during British Raj.[3] It was established as a district on 1 March 1984.[2] History of the War of Liberation In 1971 the Pak army in collaboration with their local agents conducted mass killing and plundering; they also set many houses of the district on fire. During Bangladesh Liberation War a number of encounters were held in Shariatpur Sadar Upazila between the freedom fighters and the Pak army in which about 313 Pak soldiers were killed. A number of freedom fighters were killed in two encounters and one frontal battle with the Pak army in Bhedarganj Upazila. Nine freedom fighters including Ahsanul Hoque and Abdul Wahab were killed in an encounter with the Pak army at a place on the southern side of Damudya College. Muktijoddha and Mujib Bahini jointly conducted attack on the Pak army by guerrilla technique in the upazila. Five freedom fighters were killed in an encounter with the Pak army in Gosairhat Upazila. The freedom fighters of Naria raided the Naria Police Station and captured all the arms and ammunitions of the thana. In retaliation, the Pak army sacked the nearby villages. During Bangladesh Liberation War a number of encounters were held between the freedom fighters and the Pak army in Zanjira Upazila in which a number of freedom fighters were killed.</p>
<h3>Administration</h3> <hr/>
<p> There are six upazilas (sub-districts) under this district,[6] namely:</p>
<h4>There are six upazilas (sub-districts) under this district,[6] namely:</h4>
<img align="right" src="spur2.png">
<h3>1.Shariatpur Sadar Upazila</h3>
<h3>2.Damudya Upazila</h3>
<h3>3.Zanjira Upazila </h3>
<h3>4.Bhedarganj Upazila </h3>
<h3>5.Gosairhat Upazila </h3>
<h3>6.Shakhipur Upazila </h3></br>
<h3>Education</h3><hr/>
<p>There are 772 primary schools,19 lower secondary schools,83 secondary schools and 42 Madrasas in Shariatpur. There are also 3 Public and 13 Private Colleges, 1 polytechnic Institute, 1 Vocational School and College, 1 Private University and one private medical college. The literacy rate (7+ year) 60% (Male 63%, Female 57%) and literacy rate (15+ year) 41% (Male 47%, Female 36%).</p>
</body>
</html> 