<?php

include "db_connect.php";
//session_start();
$error = "";

if (isset($_COOKIE['user'])) {
    header("location: index.php");
}

if (isset($_POST['submit'])) {
    $email    = $_POST['email'];
    $password = $_POST['password'];
    $password = md5($password);

    $sql    = "SELECT * FROM users WHERE email='$email' AND password='$password'";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        // $_SESSION['user'] = 1;
        setcookie("user", $_POST['email'], time() + 60 * 60 * 24, "/");

        header("location: index.php");
    } else {
        $error = "Incorrect email or password<br><br>";
    }
}


function validate_data($val)
{
    $val = trim($val);
    $val = stripslashes($val);
    $val = htmlspecialchars($val);

    return $val;
}

$error   = "";
$success = "";
$color   = "";
$flag    = 0;

if (isset($_POST['submit2'])) {
    $text             = $_POST['text'];
    $email            = $_POST['email'];
    $password         = $_POST['password'];
    $password2        = $_POST['password2'];

    if (empty($text) || empty($email) || empty($password) || empty($password2)){
        $error = "You did not fill out the required fields!<br>";
        $color = "red";
    } else {
        if ($password != $password2) {
            $error = "Password & Confirm Password is not same<br>";
            $color = "red";
        } else {
            $text  = validate_data($text);
            $email       = validate_data($email);
            $password    = validate_data($password);

            $password = md5($password);

            $sql    = "INSERT into users(name,email,password) values('$text','$email','$password')";
            $result = mysqli_query($conn, $sql);
            if ($result) {
                $success = "Account Created Successfully!<br>";
                $color   = "green";
                $flag    = 1;
            } else {
                $error = "Account with the following email or number Already exist!<br>";
                $color = "red";
            }
        }
    }
}

?>
<html>
<title> Login Form </title>
<head>
<link rel="stylesheet" href="form.css" />
</head>
<body>
<div class="hero">
<nav>
<div class="button-box" >
<div id="btn"> </div>
<button type="button" class="toggle-btn" onclick="login()">Log In</button>
<button type="button" class="toggle-btn" onclick="register()">Register</button>
</div>
 <form id="login" action="" method="post" class="input-group">
 <input type="email" name="email"  class="input-field" placeholder="Email" required> 
<input type="password" name="password" class="input-field" placeholder="Enter Password" required>
<input type="checkbox" name="checkbox" class="check-box"><span> Remember Password</span> 
<button type="submit" name="submit" class="submit-btn">Log In</button> 
 </form>
 <form id="register" action="" method="post" class="input-group">
 <input type="text" name="text" class="input-field" placeholder="Name" name="name" required>  
 <input type="email" name="email" class="input-field" placeholder="Email" name="email" required> 
<input type="password" name="password" class="input-field" placeholder="Password" name="password" required>
<input type="password" name="password2" class="input-field" placeholder="Confirm Password" name="confirm_password" required>
<input type="checkbox" name="checkbox" class="check-box"><span>I agree to the terms & conditions</span> 
<button type="submit" name="submit2" class="submit-btn">Register</button> 
 </form>
</nav>
</div>
<script>
var x= document.getElementById("login");
var y= document.getElementById("register");
var z= document.getElementById("btn");
function register(){
x.style.left= "-400px";
y.style.left= "50px";
z.style.left= "110px";

}
function login(){
x.style.left= "50px";
y.style.left= "450px";
z.style.left= "0px";

}
</script>
</body>
</html>