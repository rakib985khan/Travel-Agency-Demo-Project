<html>
<head>
<link rel="stylesheet" href="style.css">
</head>
<body>
<h1> Sign Up </h1>
<p> Plese fill in this form to create an account!</p>
<form>
  <label for="fname">First name:</label><br>
  <input type="text" id="fname" name="fname" value="Md Rakib"><br>
  <label for="lname">Last name:</label><br>
  <input type="text" id="lname" name="lname" value="Khan"><br>
  <label for="email">Email:</label> <br>
  <input type="email" id="email" value="rakib.982khan@gmail.com"><br>
  <label for="password">Password:</label> <br>
  <input type="password" id="password" value="12345"><br>
  <label for="password">Confirm Password:</label> <br>
  <input type="password" id="password" value="12345"><br>
  <input type="checkbox" id="condition">
  <label for="condition">I accept the Terms of use & Privacy Policy </label><br>
  <input type="submit" value="Sign Up">
</form>
</body>
</html>