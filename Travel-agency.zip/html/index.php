<?php
include "db_connect.php";

if (isset($_POST['logout'])) {
    //session_destroy();
    setcookie("user", "", time() - 60 * 60 * 24, "/");
    header("location:index.php");
}

?>
<html>
<title>Travel Agency </title>
<head>
<link rel="stylesheet" href="project.css" />
</head>
<body>
<nav>
    <label class="logo"> Travel Agency </label>
  <ul>
   <li><a class="active" href="#">Home </a></li>
   <li><a href="about.php">About Us </a></li>
   <li><a href="package.php">Package Tour  </a></li>
   <li><a href="#">Blog </a></li>
   <li><a href="contact.php">Contact </a></li>
   <li><a href="#">Book Now </a></li>
   <li><a href="form.php">Log in </a></li>
   <?php if (isset($_COOKIE['user'])) {
    echo "
      <li><form action=\"\" method=\"post\"> <button type=\"submit\" name=\"logout\" class=\"navbutton\">Log Out</button>
    </form></a>
    </div>
  </div> </li>";
}
?>
</ul>
</nav>
<section> 
<div class="content">
<h1> Make Your Tour Amazing With Us</h1>
<p> Travel to the any corner of the world.whitout going around in circle</p><br><br><br>
<div>
<button type="button"  class="bangbang" ><span> </span>Destination</button>
<button type="button"  class="bangbang" ><span> </span>Check-in date</button>
<button type="button"  class="bangbang" ><span> </span>Check-out date</button>
<button type="button"  class="bangbang" ><span> </span>Price limit</button>
</div>
</section>
</body>
</html>