<html>
<title>Package Tour </title>
<head>
<link rel="stylesheet" href="package.css" />
</head>
<body>
<section>
<div>
<button type="button" ><span> </span>5 Day & 7 Night Bandarban </br> <img src="about2.jpg" width="415" height="332"></button>
<button type="button" ><span> </span>2 Day & 3 Night Kuakata</br> <img src="kuakata.jpg" width="415" height="332"> </button>
<button type="button" ><span> </span>5 Day & 7 Night Cox-Bazar</br> <img src="cox.jpg" width="415" height="332"> </button>
<button type="button" ><span> </span>2 Day & 2 Night ZHSUST</br> <img src="zh.jpg" width="415" height="332"> </button>
<button type="button" ><span> </span>7 Day & 5 Night Rangpur </br> <img src="mma.jpg" width="415" height="332"></button>
<button type="button" ><span> </span>15 Day & 13 Night Nepal </br> <img src="banner.jpg" width="415" height="332"></button>
</div>
</section>
</body>
</html>