<?php
$name=$_POST['name'];
$email=$_POST['email'];
$password=$_POST['password'];
$confirm_password=$_POST['confirm_password'];
$conn = new mysqli('localhost','root','','project');
if(conn->project_error){
	die('connection Faild :'.$conn->project_error);
}
else{
	$stmt=$conn->prepare("insert into Registation(Name,Email,Password,confirm_password)
	values(?,?,?,?)");
	$stmt->bind_param("ssss",$name,$email,$password,$confirm_password);
	$stmt->execute();
	echo "Registation Succesfully...";
	$stmt-> close();
	$conn->close();
}
?>